import java.util.Scanner;

public class Task3 {

	public static void main(String[] args) {
		Scanner reader = new Scanner(System.in);

		System.out.print("Type the number of the elements: ");
		int nr = reader.nextInt();
		int[] array = new int[nr];

		for (int i = 0; i < array.length; i++) {
			System.out.print("Type element number " + (i + 1) + " : ");
			array[i] = reader.nextInt();

		}
		printarray(array);

		System.out.println(result(0, array));
		
		reader.close();
	}

	private static boolean result(int pos, int[] array) {
		if (pos == array.length - 1) {
			return true;
		}
		if (array[pos] == 0) {
			return false;
		}
		boolean again = false;

		for (int step = 1; step <= array[pos]; step++) {
			if (pos + step < array.length) {
				again = again || result(pos + step, array);
			}
		}
		return again;
	}

	private static void printarray(int[] array) {
		for (int i = 0; i < array.length; i++) {
			System.out.print(array[i] + " ");
		}

	}

}
